document.addEventListener("DOMContentLoaded", function() {
    const form = document.querySelector('form');

    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Previne o comportamento padrão do formulário de enviar

        const formData = new FormData(this); // Obtém os dados do formulário

        fetch('/cadastro_alunos/cadastro.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao enviar dados para o servidor.');
            }
            return response.text();
        })
        .then(data => {
            console.log('Dados inseridos com sucesso:', data);
            // Limpa os valores dos inputs após enviar com sucesso
            form.reset();
        })
        .catch(error => {
            console.error('Erro:', error);
        });
    });
});
