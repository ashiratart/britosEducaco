document.getElementById("myForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Evita o envio do formulário padrão

    // Obtém os valores dos campos de entrada
    var nome = document.getElementById("nome").value;
    var cpf = document.getElementById("cpf").value;
    var turma = document.getElementById("turma").value;

    // Cria um objeto com os dados a serem enviados
    var formData = {
        name: nome,
        cpfCnpj: cpf,
        groupName: turma
    };

    // Envia os dados para o arquivo PHP usando AJAX
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "enviarAPI.php", true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                console.log(xhr.responseText);
            } else {
                console.error("Erro na requisição");
            }
        }
    };
    xhr.send(JSON.stringify(formData));
});
