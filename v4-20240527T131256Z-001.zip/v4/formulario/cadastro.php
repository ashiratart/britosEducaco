<?php
// Conexão com o banco de dados MySQL
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "britoseducacao";

// Cria a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

// Prepara a declaração SQL para inserir os dados do formulário
$stmt = $conn->prepare("INSERT INTO alunos (nome, cpf, data_nascimento, rg, inicio_do_curso, fim_do_curso, ensino_medio, naturalidade, uf, mae, pai, data_pagamento, curso, turma) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

// Obtém os dados do formulário
$nome = $_POST['nome'];
$cpf = $_POST['cpf'];
$rg = $_POST['rg'];
$data_nascimento = $_POST['data-nascimento'];
$inicio_curso = $_POST['ini-curso'];
$fim = $_POST['fim'];
$ensino_medio = $_POST['ensino'];
$naturalidade = $_POST['naturalidade'];
$uf = $_POST['uf'];
$mae = $_POST['mae'];
$pai = $_POST['pai'];
$data_pagamento = $_POST['pagamento'];
$curso = $_POST['curso'];
$turma = $_POST['turma'];

// Define os parâmetros e executa a declaração SQL
$stmt->bind_param("ssssssssssssss", $nome, $cpf, $data_nascimento, $rg, $inicio_curso, $fim, $ensino_medio, $naturalidade, $uf, $mae, $pai, $data_pagamento, $curso, $turma);
$stmt->execute();

// Verifica se a inserção foi bem-sucedida
if ($stmt->affected_rows > 0) {
    echo "Dados inseridos com sucesso.";
} else {
    echo "Erro ao inserir os dados.";
}

// Fecha a declaração e a conexão com o banco de dados
$stmt->close();
$conn->close();
?>
