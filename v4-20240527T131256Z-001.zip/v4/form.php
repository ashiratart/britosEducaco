<?php
// Configurações do banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "britoseducacao";

// Cria uma conexão com o banco de dados
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica se a conexão foi estabelecida com sucesso
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Inicializa um array para a resposta JSON
$response = array();

// Verifica se foram passados dados via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtém os dados do POST
    $id_usuario = $_POST["id_usuario"];
    $senha = $_POST["senha"];

    // Prepara a consulta SQL para verificar as credenciais
    $sql = "SELECT id FROM usuarios_form WHERE id_user = '$id_usuario' AND senha = '$senha'";
    $result = $conn->query($sql);

    // Verifica se a consulta retornou algum resultado
    if ($result->num_rows > 0) {
        // Obtém o ID do usuário
        $usuario = $result->fetch_assoc();
        $id = $usuario['id'];

        // Configura a resposta JSON com sucesso e o ID do usuário
        $response['success'] = true;
        $response['id'] = $id;
    } else {
        // Configura a resposta JSON com falha
        $response['success'] = false;
    }
} else {
    // Se não houver dados POST, configura a resposta JSON com erro
    $response['error'] = "Erro: Nenhum dado enviado.";
}

// Fecha a conexão com o banco de dados
$conn->close();

// Envia a resposta JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
