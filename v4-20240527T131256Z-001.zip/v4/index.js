function form() {
    alert("Oi bem vindo ao sistema de cadastro de alunos\nPoderia me fornecer suas credenciais?");
    let iduser = prompt("Adicione o seu id, por favor");
    let senha = prompt("Adicione sua senha");

    // Enviar os dados via AJAX para o arquivo PHP correspondente
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "/cadastro_alunos/form.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Processar a resposta JSON
                var response = JSON.parse(xhr.responseText);
                if (response.success) {
                    window.location.href = "/cadastro_alunos/form.html?id_usuario=" + response.id;
                } else {
                    alert("Credenciais inválidas.");
                }
            } else {
                alert("Ocorreu um erro durante a requisição.");
            }
        }
    };
    xhr.send("id_usuario=" + iduser + "&senha=" + senha);
}

function bol() {
    alert("Oi bem vindo ao sistema de cadastro de alunos\nPoderia me fornecer suas credenciais?");
    let iduser = prompt("Adicione o seu id, por favor");
    let senha = prompt("Adicione sua senha");

    // Enviar os dados via AJAX para o arquivo PHP correspondente
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "/cadastro_alunos/bol.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Processar a resposta JSON
                var response = JSON.parse(xhr.responseText);
                if (response.success) {
                    window.location.href = "/cadastro_alunos/recuperar/index.php?id_usuario=" + response.id;
                } else {
                    alert("Credenciais inválidas.");
                }
            } else {
                alert("Ocorreu um erro durante a requisição.");
            }
        }
    };
    xhr.send("id_usuario=" + iduser + "&senha=" + senha);
}
