<?php
//iniciar como vazio
$GroupName = "";

// Verifica se um número de grupo foi enviado via POST
if(isset($_POST['GroupName'])) {
    // Sanitize para evitar XSS (Cross-Site Scripting)
    $GroupName = htmlspecialchars($_POST['GroupName']);
}

// URL da primeira API com o parâmetro groupName=3 para filtrar clientes com groupName de valor 3
$url = "http://asaas.com/api/v3/payments?customerGroupName=$GroupName&limit=100";

// Opções para a primeira solicitação
$options = array(
    'http' => array(
        'header' => 'Accept: application/json' . "\r\n" .
                    'Access-Token: $aact_YTU5YTE0M2M2N2I4MTliNzk0YTI5N2U5MzdjNWZmNDQ6OjAwMDAwMDAwMDAwMDAzNzMwMDU6OiRhYWNoX2Q2OWJlYjY5LWQ0M2UtNGExOS04MjI3LTg2MGYxNjk2YmQ2OQ==' . "\r\n"
    )
);

// Realizar a primeira solicitação à API
$response = file_get_contents($url, false, stream_context_create($options));

// Verificar se houve algum erro na primeira solicitação
if ($response === false) {
    echo "Erro ao acessar a API.";
    exit;
}

// Decodificar o JSON retornado da primeira solicitação
$clientes = json_decode($response, true);

// Verificar se houve erro na decodificação do JSON
if (json_last_error() !== JSON_ERROR_NONE) {
    echo "Erro ao decodificar JSON.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pegar Cobranças</title>
</head>

<link rel="stylesheet" href="estilo1.css">

<body>
     <!-- Adiciona um script para solicitar o número do grupo -->
     <script>
        function solicitarNumeroGrupo() {
            var numeroGrupo = prompt("Por favor, insira o número do grupo:");
            if (numeroGrupo !== null) {
                // Redireciona para a mesma página com o número do grupo como parâmetro POST
                var form = document.createElement('form');
                form.method = 'post';
                form.action = '';
                var input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'GroupName';
                input.value = numeroGrupo;
                form.appendChild(input);
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>

    <!-- Chama a função para solicitar o número do grupo ao usuário -->
    <button onclick="solicitarNumeroGrupo()">Clique aqui para inserir o número do grupo</button>

    <!-- Tabela para exibir os nomes, id e cpfCnpj dos clientes -->
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Numero da cobrança</th>
                <th>link</th>
            </tr>
        </thead>
        <tbody>
            <?php
                // Iterar sobre os clientes e exibir suas informações na tabela
                foreach ($clientes['data'] as $cliente) {
                    echo "<tr>";
                    echo "<td>{$cliente['id']}</td>";
                    echo "<td>{$cliente['customer']}</td>";
                    echo '<td><a href="' . $cliente['invoiceUrl'] . '">' . $cliente['invoiceUrl'] . '</a></td>';
                    echo "</tr>";
                }                
                ?>
        </tbody>
    </table>
</body>

</html>
