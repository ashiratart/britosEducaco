<?php
// Inicializa a variável $groupName
$groupName = "";

// Verifica se um número de grupo foi enviado via POST
if(isset($_POST['groupName'])) {
    // Sanitize para evitar XSS (Cross-Site Scripting)
    $groupName = htmlspecialchars($_POST['groupName']);
}

// URL da API com o parâmetro groupName fornecido pelo usuário
$url = "http://sandbox.asaas.com/api/v3/customers?groupName=$groupName";

// Opções para a solicitação à API
$options = array(
    'http' => array(
        'header' => 'Accept: application/json' . "\r\n" .
                    'Access-Token: $aact_YTU5YTE0M2M2N2I4MTliNzk0YTI5N2U5MzdjNWZmNDQ6OjAwMDAwMDAwMDAwMDAwNzU2NTk6OiRhYWNoX2ExOWMxMzdlLWIyOWEtNDE4ZS1hMDM0LTZmNTY1NTE0ZjJiYQ==' . "\r\n"
    )
);

// Realiza a solicitação à API
$response = file_get_contents($url, false, stream_context_create($options));

// Verifica se houve algum erro na solicitação
if ($response === false) {
    echo "Erro ao acessar a API.";
    exit;
}

// Decodifica o JSON retornado
$clientes = json_decode($response, true);

// Verifica se houve erro na decodificação do JSON
if (json_last_error() !== JSON_ERROR_NONE) {
    echo "Erro ao decodificar JSON.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pegar alunos</title>
</head>

<body>
    <h1>Pegar Alunos para fazer o boleto</h1>

    <!-- Adiciona um script para solicitar o número do grupo -->
    <script>
        function solicitarNumeroGrupo() {
            var numeroGrupo = prompt("Por favor, insira o número do grupo:");
            if (numeroGrupo !== null) {
                // Redireciona para a mesma página com o número do grupo como parâmetro POST
                var form = document.createElement('form');
                form.method = 'post';
                form.action = '';
                var input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'groupName';
                input.value = numeroGrupo;
                form.appendChild(input);
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>

    <!-- Chama a função para solicitar o número do grupo ao usuário -->
    <button onclick="solicitarNumeroGrupo()">Clique aqui para inserir o número do grupo</button>

    <!-- Tabela para exibir os nomes, id e cpfCnpj dos clientes -->
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome do Cliente</th>
                <th>CPF/CNPJ</th>
                <th>Selecionar</th>
            </tr>
        </thead>
        <tbody>
            <?php
                // Itera sobre os clientes e exibe suas informações na tabela
                foreach ($clientes['data'] as $cliente) {
                    echo "<tr>";
                    echo "<td>{$cliente['id']}</td>";
                    echo "<td>{$cliente['name']}</td>";
                    echo "<td>{$cliente['cpfCnpj']}</td>";
                    // Adiciona um checkbox para selecionar o cliente e preencher o campo cliente_id
                    echo "<td><input type='checkbox' name='selected_clients[]' value='{$cliente['id']}'></td>";
                    echo "</tr>";
                }
                ?>
        </tbody>
    </table>

    <!-- Formulário para enviar dados e criar boleto -->
    <form id="boletoForm">
        <input type="number" name="mensalidade" id="mensalidade" placeholder="Mensalidade">
        <input type="number" name="desconto" id="desconto" placeholder="Desconto">
        <input type="text" name="descricao" id="descricao" placeholder="Descrição">
        <input type="date" name="data" id="data" value="<?php echo date('Y-m-d'); ?>">
        <button type="button" onclick="fazerBoleto()">Fazer Boletos</button>
    </form>

    <script>
        function fazerBoleto() {
            const form = document.getElementById("boletoForm");
            const formData = new FormData(form);
            const selectedClients = [];
            const checkboxes = document.querySelectorAll('input[name="selected_clients[]"]:checked');
            checkboxes.forEach((checkbox) => {
                selectedClients.push(checkbox.value);
            });

            // Verifica se pelo menos um cliente foi selecionado
            if (selectedClients.length === 0) {
                alert("Por favor, selecione pelo menos um cliente.");
                return;
            }

            formData.delete('selected_clients'); // Remove o parâmetro anterior

            // Adiciona cada cliente selecionado como um parâmetro individual
            selectedClients.forEach((clientId) => {
                formData.append('selected_clients[]', clientId);
            });

            fetch('criarBoletos.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    console.log(data);
                    // Faça algo com a resposta, como exibir uma mensagem de sucesso ou erro
                })
                .catch(error => {
                    console.error('Erro:', error);
                });
        }
    </script>

</body>

</html>
