<?php
// Recebe os dados do corpo da solicitação
$data = json_decode(file_get_contents("php://input"), true);

// Verifica se os dados foram recebidos corretamente
if (!empty($data['name']) && !empty($data['cpfCnpj']) && !empty($data['groupName'])) {
    // URL para fazer a requisição
    $url = 'https://sandbox.asaas.com/api/v3/customers';

    // Dados a serem enviados no corpo da solicitação
    $postData = json_encode([
        'name' => $data['name'],
        'cpfCnpj' => $data['cpfCnpj'],
        'groupName' => $data['groupName']
    ]);

    // Opções da solicitação
    $options = array(
        'http' => array(
            'method' => 'POST',
            'header' => 'Content-Type: application/json' . "\r\n" .
                        'Accept: application/json' . "\r\n" .
                        'Access-Token: $aact_YTU5YTE0M2M2N2I4MTliNzk0YTI5N2U5MzdjNWZmNDQ6OjAwMDAwMDAwMDAwMDAwNzU2NTk6OiRhYWNoX2ExOWMxMzdlLWIyOWEtNDE4ZS1hMDM0LTZmNTY1NTE0ZjJiYQ==' . "\r\n",
            'content' => $postData
        )
    );

    // Cria o contexto da solicitação
    $context = stream_context_create($options);

    // Faz a solicitação
    $result = file_get_contents($url, false, $context);

    // Verifica se a solicitação foi bem-sucedida
    if ($result === FALSE) {
        echo "Erro na requisição";
    } else {
        echo $result;
    }
} else {
    echo "Erro: Dados incompletos";
}
?>
