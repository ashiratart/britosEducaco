<?php
// Conexão com o banco de dados MySQL
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "britoseducacao";

// Cria a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    echo("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

// Pesquisar no banco de dados
$sql = "SELECT nome, cpf, turma FROM `alunos` WHERE alunos.turma = '3'";
$result = $conn->query($sql);

// Guarda resultados
$data = array();

// Se houver resultados, monta um array com os dados
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    // Enviar os dados para a solicitação HTTP
    foreach ($data as $row) {
        // URL para fazer a requisição
        $url = 'https://asaas.com/api/v3/customers';

        // Dados a serem enviados no corpo da solicitação
        $postData = json_encode([
            'name' => $row['nome'],
            'cpfCnpj' => $row['cpf'],
            'groupName' => $row['turma']
        ]);

        // Opções da solicitação
        $options = array(
            'http' => array(
                'method' => 'POST',
                'header' => 'Content-Type: application/json' . "\r\n" .
                            'Accept: application/json' . "\r\n" .
                            'Access-Token: $aact_YTU5YTE0M2M2N2I4MTliNzk0YTI5N2U5MzdjNWZmNDQ6OjAwMDAwMDAwMDAwMDAzNzMwMDU6OiRhYWNoX2Q2OWJlYjY5LWQ0M2UtNGExOS04MjI3LTg2MGYxNjk2YmQ2OQ==' . "\r\n",
                'content' => $postData
            )
        );

        // Cria o contexto da solicitação
        $context = stream_context_create($options);

        // Faz a solicitação
        $result = file_get_contents($url, false, $context);

        // Verifica se a solicitação foi bem-sucedida
        if ($result === FALSE) {
            echo "Erro na requisição";
        } else {
            echo $result;
        }
    }
} else {
    echo "Nenhum resultado encontrado";
}

// Fecha a conexão
$conn->close();
?>
