$(document).ready(function() {
    // Quando a página é carregada, faz uma requisição AJAX para obter os dados da tabela
    $.ajax({
        url: 'obter_dados.php', // URL do script PHP que irá retornar os dados da tabela
        method: 'GET',
        dataType: 'json',
        success: function(data) {
            // Quando a requisição é bem-sucedida, preenche a tabela com os dados retornados
            // Cabeçalho da tabela
            var headerRow = '<tr>';
            headerRow += '<th>ID</th>';
            headerRow += '<th>Nome</th>';
            headerRow += '<th>CPF</th>';
            headerRow += '<th>Data de Nascimento</th>';
            headerRow += '<th>RG</th>';
            headerRow += '<th>Início do Curso</th>';
            headerRow += '<th>Fim do Curso</th>';
            headerRow += '<th>Ensino Médio</th>';
            headerRow += '<th>Naturalidade</th>';
            headerRow += '<th>UF</th>';
            headerRow += '<th>Mãe</th>';
            headerRow += '<th>Pai</th>';
            headerRow += '<th>Data de Pagamento</th>';
            headerRow += '<th>Curso</th>';
            headerRow += '<th>Turma</th>';
            headerRow += '</tr>';
            $('#tabela-dados thead').html(headerRow);

            // Preenchendo as linhas da tabela com os dados
            var bodyRows = '';
            data.forEach(function(item) {
                bodyRows += '<tr>';
                bodyRows += '<td>' + item.id + '</td>';
                bodyRows += '<td>' + item.nome + '</td>';
                bodyRows += '<td>' + item.cpf + '</td>';
                bodyRows += '<td>' + item.data_nascimento + '</td>';
                bodyRows += '<td>' + item.rg + '</td>';
                bodyRows += '<td>' + item.inicio_do_curso + '</td>';
                bodyRows += '<td>' + item.fim_do_curso + '</td>';
                bodyRows += '<td>' + item.ensino_medio + '</td>';
                bodyRows += '<td>' + item.naturalidade + '</td>';
                bodyRows += '<td>' + item.uf + '</td>';
                bodyRows += '<td>' + item.mae + '</td>';
                bodyRows += '<td>' + item.pai + '</td>';
                bodyRows += '<td>' + item.data_pagamento + '</td>';
                bodyRows += '<td>' + item.curso + '</td>';
                bodyRows += '<td>' + item.turma + '</td>';
                bodyRows += '</tr>';
            });
            $('#tabela-dados tbody').html(bodyRows);
        }
    });
});
