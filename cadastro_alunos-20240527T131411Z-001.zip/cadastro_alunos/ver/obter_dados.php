<?php
// Conecta ao banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "britoseducacao";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query para selecionar todos os dados da tabela
$sql = "SELECT * FROM alunos";
$result = $conn->query($sql);

$data = array();

// Se houver resultados, monta um array com os dados
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Fecha a conexão
$conn->close();

// Retorna os dados como JSON
header('Content-Type: application/json');
echo json_encode($data);
?>
