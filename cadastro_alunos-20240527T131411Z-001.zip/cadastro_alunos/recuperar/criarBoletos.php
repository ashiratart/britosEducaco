<?php

// Verifica se os dados do formulário foram recebidos
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recupera os dados do formulário
    $mensalidade = $_POST['mensalidade'];
    $desconto = $_POST['desconto'];
    $data = $_POST['data'];
    $selectedClients = $_POST['selected_clients'];

    // Dados da requisição para o Asaas API
    $url = 'https://sandbox.asaas.com/api/v3/payments';
    $headers = array(
        'Accept: application/json',
        'Content-Type: application/json',
        'Access_token: $aact_YTU5YTE0M2M2N2I4MTliNzk0YTI5N2U5MzdjNWZmNDQ6OjAwMDAwMDAwMDAwMDAwNzU2NTk6OiRhYWNoX2ExOWMxMzdlLWIyOWEtNDE4ZS1hMDM0LTZmNTY1NTE0ZjJiYQ=='
    );

    // Inicializa o cURL
    $ch = curl_init($url);

    foreach ($selectedClients as $clientId) {
        $data = array(
            'customer' => $clientId,
            'billingType' => 'BOLETO',
            'discount' => array(
                'value' => $desconto,
                'dueDateLimitDays' => 0,
                'type' => 'FIXED'
            ),
            'interest' => array(
                'value' => 2
            ),
            'value' => $mensalidade,
            'dueDate' => date('Y-m-d', strtotime($data)) // Ajusta o formato da data
        );

        // Configura as opções do cURL
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Executa a requisição
        $response = curl_exec($ch);

        // Verifica se ocorreu algum erro
        if(curl_errno($ch)){
            echo 'Erro ao fazer requisição: ' . curl_error($ch);
        }

        // Faça algo com a resposta, como exibir uma mensagem de sucesso ou erro
        echo $response;
    }

    // Fecha o cURL
    curl_close($ch);
}
?>
