<?php
// Configurações do banco de dados
$host = "localhost";
$usuario = "root";
$senha = "";
$banco = "britosEducacao";

// Conexão com o banco de dados
$conn = new mysqli($host, $usuario, $senha, $banco);

// Verifica a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Query para obter dados da tabela disciplinasBritos
$query = "SELECT id, disciplina, professor, titulo, periodo, imgDisc FROM disciplinasBritos";
$result = $conn->query($query);

// Verifica se a query foi bem-sucedida
if ($result) {
    // Array para armazenar os resultados
    $dados = array();

    // Fetch os resultados da query
    while ($row = $result->fetch_assoc()) {
        // Adiciona cada linha ao array de dados
        $dados[] = $row;
    }

    // Converte o array em JSON e imprime
    echo json_encode($dados);
} else {
    // Se a query falhou, imprime uma mensagem de erro
    echo "Erro na execução da query: " . $conn->error;
}

// Fecha a conexão com o banco de dados
$conn->close();
?>
