<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST["idUsuario"];
    $senha = $_POST["senha"];

    // Verificar as credenciais
    if ($usuario === "usuarioTest" && $senha === "12345") {
        // Credenciais corretas
        $_SESSION["authenticated"] = true;
        echo "Autenticado";
    } else {
        // Credenciais incorretas
        echo "Login incorreto";
    }
}
?>
