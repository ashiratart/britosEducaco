<?php
// Conectar ao banco de dados (substitua os valores pelos seus)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "britosEducacao";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

// Diretório para salvar os vídeos
$videoDir = "videos/";

$titulo = $_POST['titulo'];
$resumo = $_POST['resumo'];

// Salvar o vídeo no diretório
$videoFile = $videoDir . basename($_FILES['video']['name']);
move_uploaded_file($_FILES['video']['tmp_name'], $videoFile);

// Salvar as informações no banco de dados
$sql = "INSERT INTO videos (titulo, resumo, caminho) VALUES ('$titulo', '$resumo', '$videoFile')";
$conn->query($sql);

$conn->close();
?>
