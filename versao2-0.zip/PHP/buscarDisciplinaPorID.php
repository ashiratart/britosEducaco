<?php
// Conexão com o banco de dados (substitua pelos seus dados)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "britosEducacao";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Recebe o ID da disciplina como parâmetro
$disciplinaId = $_GET['disciplinaId'];

// Query para buscar os dados da disciplina no banco de dados
$sql = "SELECT * FROM informacoesDiciplinas WHERE disciplinas_id = '$disciplinaId'";
$result = $conn->query($sql);

// Verifica se a query retornou resultados
if ($result->num_rows > 0) {
    // Converte os resultados em um array associativo
    $row = $result->fetch_assoc();

    // Converte o array em JSON e imprime
    echo json_encode($row);
} else {
    // Se não houver resultados, retorna um JSON vazio ou uma mensagem de erro
    echo json_encode(array('error' => 'Disciplina não encontrada'));
}

// Fecha a conexão
$conn->close();
?>
