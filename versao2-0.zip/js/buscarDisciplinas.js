// Função para criar as divs com base nos dados do servidor
function criarDivsComBaseNosDados(dados) {
    var disciplinasContainer = document.getElementById('disciplinasContainer');

    dados.forEach(function(disciplina) {
        var divDisciplina = document.createElement('div');
        divDisciplina.id = 'disciplina_' + disciplina.id + '_coluna';
        divDisciplina.innerHTML = `
            <div id="img_disciplina">
                <img src="${disciplina.imgDisc}">
            </div>
            <div id="informacoes_da_disciplina">
                <h3>${disciplina.titulo}</h3>
                <h5>Periodo ${disciplina.periodo}</h5>
                <p>Professor: ${disciplina.professor}</p>
            </div>
        `;
        divDisciplina.addEventListener('click', function() {
            entrar_na_disciplina(disciplina.id);
        });

        disciplinasContainer.appendChild(divDisciplina);
    });
}

// Função para redirecionar com base no ID
function entrar_na_disciplina(id) {
    window.location.href = "disciplinas_estudadas/index_disciplina.html?id=" + id;
}

// Chama a função para buscar os dados do servidor e criar as divs
fetch('/projeto/PHP/buscarDisciplinas.php')
    .then(response => response.json())
    .then(data => {
        // Aqui você pode usar os dados obtidos do servidor
        console.log(data);
        // Chame a função criarDivsComBaseNosDados e passe os dados como argumento
        criarDivsComBaseNosDados(data);
    })
    .catch(error => console.error('Erro ao buscar dados do servidor:', error));