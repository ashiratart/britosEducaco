// Recupera o ID da URL
const urlParams = new URLSearchParams(window.location.search);
const disciplinaId = urlParams.get('id');

// Agora você pode usar o disciplinaId na sua lógica
console.log(disciplinaId);


        // Função para montar a página com base nos dados
        function montarPagina(dados) {
            // Montar o vídeo
            const videoElement = document.querySelector('#videos video');
            videoElement.src = dados.video;

            // Montar resumo do vídeo
            const resumoVideo = document.querySelector('#resumo_video');
            resumoVideo.innerHTML = `
                <h3 style="text-align: center;">${dados.titulodoVideo}</h3>
                <p style="text-align: center;">${dados.resumoVideo}</p>
            `;

            // Montar material da aula
            const imgImagem2 = document.querySelector('#img_imagem2 img');
            imgImagem2.src = dados.capaDiciplina;

            const descricao = document.querySelector('#descricao');
            descricao.innerHTML = `
                <h3>${dados.tituloAula}</h3>
                <p>${dados.resumoAula}</p>
            `;

            // Montar conteúdo adicional
            const conteudoAdicional = document.querySelector('#conteudo_adicional');
            conteudoAdicional.innerHTML = `
                <h3>${dados.tituloAdicional}</h3>
                <p>${dados.resumoAdicional}</p>
                <h4><a href="${dados.conteudoAdicional_pdfLink}" download="atividade.pdf">Atividade</a></h4>
            `;
        }

        // Faz uma requisição AJAX para obter os dados da disciplina
        fetch(`/projeto/PHP/buscarDisciplinaPorID.php?disciplinaId=${disciplinaId}`)
            .then(response => response.json())
            .then(dados => montarPagina(dados))
            .catch(error => console.error('Erro na requisição AJAX:', error));