    // script.js

    window.addEventListener('DOMContentLoaded', (event) => {
        const menuToggle = document.getElementById('menu-toggle');
        const menu = document.getElementById('menu');

        menuToggle.addEventListener('change', () => {
            if (menuToggle.checked) {
                menu.style.display = 'flex';
                menu.style.flexDirection = 'column';
                menu.style.alignItems = 'center';
            } else {
                menu.style.display = 'none';
            }
        });
    });
