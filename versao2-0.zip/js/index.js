//chamar api
const id_usuario = document.getElementById('ID');
const senha = document.getElementById('senha_usuario');
const mensagemErro = document.getElementById('erroTexto');

function entrar_user() {
    console.log('Usuario:', id_usuario.value);
    console.log('Senha:', senha.value);

    $.ajax({
        type: "POST",
        url: "PHP/input.php",
        data: { idUsuario: id_usuario.value, senha: senha.value },
        success: function (response) {
            console.log(response);

            if(response === "Login incorreto"){
                //mensagem de erro
                erroTexto.style.display = "block";
                erroTexto.style.color = "red";
                erroTexto.style.fontStyle = "italic";
            }else{
                //pagina altenticacao
                 window.location.href = "dashboard.php";
            }
        },
        error: function (error) {
            console.log(error);
        }
    });
}

