function salvarVideo() {
    const videoInput = document.getElementById('Video');
    const tituloInput = document.getElementById('titulo-do-video');
    const resumoInput = document.getElementById('resumo_video');

    const formData = new FormData();
    formData.append('video', videoInput.files[0]);
    formData.append('titulo', tituloInput.value);
    formData.append('resumo', resumoInput.value);

    // Fazer chamada AJAX para o servidor PHP
    enviarDadosParaServidor(formData, '/projeto/PHP/salvarVideo.php');
}

function enviarDadosParaServidor(formData, url) {
    const xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                console.log('Dados enviados com sucesso!');
                // Aqui você pode adicionar lógica adicional se necessário
            } else {
                console.error('Erro ao enviar dados para o servidor.');
            }
        }
    };

    xhr.open('POST', url, true);
    xhr.send(formData);
}

/*function carregarFotodaAula() {
    const fotoInput = document.getElementById('foto-da-aula');
    const tituloInput = document.getElementById('titulo');
    const aulaInput = document.getElementById('Aula');

    const formData = new FormData();
    formData.append('fotoAula', fotoInput.files[0]);
    formData.append('titulo', tituloInput.value);
    formData.append('aula', aulaInput.value);

    // Fazer chamada AJAX para o servidor PHP
    enviarDadosParaServidor(formData, '/salvarFotoAula.php');
}*/

// Adicione funções semelhantes para os outros tipos de conteúdo
