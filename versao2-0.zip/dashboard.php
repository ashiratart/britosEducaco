<?php
session_start();

if (!isset($_SESSION["authenticated"]) || $_SESSION["authenticated"] !== true) {
    // Usuário não autenticado, redirecionar para a página de login
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<!-- estilos -->
<link rel="stylesheet" href="css/paginaglobal.css">

<!-- especifico da pagina -->
<link rel="stylesheet" href="css/dashboard.css">

<body>
    <header>
        <div id="logo">
            <img id="logo1" src="imagens/logo.png">
        </div>
        <input style="display: none;" type="checkbox" id="menu-toggle" checked>
        <label for="menu-toggle">&#9776; Menu</label>
        <nav id="menu">
            <ul>
                <li><a href="diciplinas/diciplinas.html">Disciplinas</a></li>
                <li><a href="boletim/boletim.html">Boletim</a></li>
                <li><a href="boletos/boletos.html">Boletos</a></li>
            </ul>
        </nav>

    </header>
    <main>
        <div id="Avisos">
            <div id="imagem_do_aviso">
                <img src="imagens/diversos-amigos-estudantes-atiram.jpg">
            </div>
            <div id="conteudo">
                <h3 id="titulo_aviso">Lorem ipsum dolor sit, amet consectetur</h3>
                <p id="conteudo_aviso">Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam quasi deleniti
                    quam,
                    molestias, repellat maiores voluptates soluta excepturi natus quae ipsam laboriosam? Dolores maiores
                    doloremque fugit minus quisquam ratione quis.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestiae incidunt reprehenderit, minima
                    laboriosam impedit saepe beatae. Numquam officia, rem ratione velit fugit voluptates ab eos vero ut
                    totam repellendus minima.
                </p>
            </div>
        </div>
        <div id="sobre_Professores">
            <div id="foto_Professor">
                <img src="imagens/photo_5177205707072711816_y.jpg">
            </div>
            <div id="texto_sobrePro">
                <h4 id="nome_professor" style="margin-bottom: 15px;">Lorem, ipsum dolor sit amet consectetur adipisicing
                    elit.</h4>
                <h5 style="margin-top: 10px;"><a href="pdf/Historico escolar.pdf" download="abc.pdf">Mais sobre mim</a>
                </h5>
            </div>
        </div>
    </main>
    <footer>
        <div id="contatos">
            <h3>Britos&Educação</h3>
            <h3>Ashira Tart Company</h3>
        </div>
    </footer>
</body>
<script src="js/interacao.js">
</script>

</html>
